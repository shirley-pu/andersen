#!/bin/sh 

java -jar RunCurvature.jar
